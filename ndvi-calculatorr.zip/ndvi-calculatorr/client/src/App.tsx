import BaselineAssessment from './components/BaselineAssessment';
import './App.css';

function App() {
  return (
    <div className="app">
      <BaselineAssessment />
    </div>
  );
}

export default App;