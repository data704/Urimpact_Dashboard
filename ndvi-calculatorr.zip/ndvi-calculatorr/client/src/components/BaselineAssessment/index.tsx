import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import MapboxDraw from '@mapbox/mapbox-gl-draw';
import { 
  Circle, Map as MapIcon, Layers, Trash2, HelpCircle, 
  BarChart3, TreePine, Leaf, Activity, Download 
} from 'lucide-react';
import LayerControls from '../LayerControls';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import './styles.css';

mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN as string;

interface BaselineData {
  aoi: number[][];
  siteDefinition: any;
  existingVegetation: any;
  agbEstimation: any;
  baselineImagery: any;
  timestamp: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const BaselineAssessment: React.FC = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const draw = useRef<MapboxDraw | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [baselineData, setBaselineData] = useState<BaselineData | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'site' | 'vegetation' | 'agb' | 'imagery'>('overview');
  const [drawnAreaSize, setDrawnAreaSize] = useState<number | null>(null);
  const [showDummyTrees, setShowDummyTrees] = useState(true); // Show by default
  const [dummyTreeCount, setDummyTreeCount] = useState(180); // Default count for dense grid

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/satellite-v9',
      center: [46.690194610355434, 24.595934489336507], // Correct center coordinates
      zoom: 15 // Closer zoom to see trees better
    });

    map.current.addControl(new mapboxgl.NavigationControl());

    draw.current = new MapboxDraw({
      displayControlsDefault: false,
      controls: {
        polygon: true,
        trash: true
      }
    });

    map.current.addControl(draw.current);

    // Handle tile loading errors gracefully (suppress "ee" errors from failed tile requests)
    map.current.on('error', (e: any) => {
      // Suppress errors from Google Earth Engine tile loading failures
      // The error can be a string "ee" or an Error object
      const errorObj = e.error;
      let errorMessage = '';
      
      if (typeof errorObj === 'string') {
        errorMessage = errorObj;
      } else if (errorObj?.message) {
        errorMessage = String(errorObj.message);
      } else if (errorObj?.toString) {
        errorMessage = errorObj.toString();
      }
      
      // Check if this is an Earth Engine tile loading error
      // The error is often just the string "ee" or contains "ee"
      if (
        errorMessage === 'ee' ||
        errorMessage.trim() === 'ee' ||
        errorMessage.toLowerCase().includes('ee') ||
        errorMessage.includes('earthengine') ||
        errorMessage.includes('Failed to load image') ||
        errorMessage.includes('Image decode failed') ||
        (errorObj?.stack && String(errorObj.stack).includes('earthengine'))
      ) {
        // Silently suppress tile loading errors - tiles may fail due to auth, CORS, or network issues
        // These are expected when Earth Engine tiles fail to load and don't need to be logged
        return; // Don't log - just suppress silently
      }
      
      // Log other errors that aren't related to Earth Engine tiles
      if (errorMessage && errorMessage !== 'ee' && errorMessage.trim() !== 'ee') {
        console.error('Map error:', e.error);
      }
    });

    // Handle source data loading errors
    map.current.on('sourcedata', (e: any) => {
      if (e.isSourceLoaded && e.source && e.source.type === 'raster') {
        // Check if source has errors
        if (e.source.tiles && e.source.tiles.length > 0) {
          // Source loaded successfully
        }
      }
    });

    // Load dummy tree data after map style loads
    map.current.on('style.load', () => {
      loadDummyTrees();
    });

    // Also try loading immediately (in case style is already loaded)
    if (map.current.isStyleLoaded()) {
      loadDummyTrees();
    }

    // Listen for draw events
    map.current.on('draw.create', (e: any) => {
      setError(null); // Clear any previous errors
      calculateAreaSize(e.features[0]);
    });

    map.current.on('draw.update', (e: any) => {
      if (e.features.length > 0) {
        calculateAreaSize(e.features[0]);
      }
    });

    map.current.on('draw.delete', () => {
      setError(null);
      setDrawnAreaSize(null);
    });

    // Don't load default AOI automatically - let user draw their own
    // loadDefaultAOI();

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  // Generate dense tree grid for plantation (180 trees in a grid pattern)
  const generateDenseTreeGrid = () => {
    // Center coordinates: 46.690194610355434, 24.595934489336507
    // Create a bounding box around the center (approximately 0.02 degrees = ~2km)
    const centerLng = 45.42677468475649;  
    const centerLat = 25.86014219961222;
    const offset = 0.01; // ~1km radius
    
    const minLng = centerLng - offset;
    const maxLng = centerLng + offset;
    const minLat = centerLat - offset;
    const maxLat = centerLat + offset;
    
    const rows = 12;
    const cols = 15;
    const trees: any[] = [];
    let id = 1;
    
    const lngStep = (maxLng - minLng) / cols;
    const latStep = (maxLat - minLat) / rows;
    const species = ['Date Palm', 'Acacia', 'Date Palm', 'Acacia', 'Date Palm'];
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        // Add randomness to avoid perfect grid
        const lng = minLng + (col * lngStep) + (Math.random() - 0.5) * lngStep * 0.3;
        const lat = minLat + (row * latStep) + (Math.random() - 0.5) * latStep * 0.3;
        
        // Health score distribution (mostly healthy, some moderate, few poor)
        const rand = Math.random();
        let healthScore: number, ndvi: number, canopyDiameter: number;
        
        if (rand < 0.4) {
          healthScore = 5;
          ndvi = 0.7 + Math.random() * 0.15;
          canopyDiameter = 8 + Math.random() * 3;
        } else if (rand < 0.7) {
          healthScore = 4;
          ndvi = 0.6 + Math.random() * 0.1;
          canopyDiameter = 6 + Math.random() * 2.5;
        } else if (rand < 0.9) {
          healthScore = 3;
          ndvi = 0.5 + Math.random() * 0.1;
          canopyDiameter = 5 + Math.random() * 2;
        } else if (rand < 0.97) {
          healthScore = 2;
          ndvi = 0.4 + Math.random() * 0.1;
          canopyDiameter = 4 + Math.random() * 1.5;
        } else {
          healthScore = 1;
          ndvi = 0.3 + Math.random() * 0.1;
          canopyDiameter = 3 + Math.random() * 1;
        }
        
        trees.push({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [lng, lat]
          },
          properties: {
            id: id++,
            healthScore: healthScore,
            ndvi: parseFloat(ndvi.toFixed(2)),
            species: species[Math.floor(Math.random() * species.length)],
            canopyDiameter: parseFloat(canopyDiameter.toFixed(1))
          }
        });
      }
    }
    
    return {
      type: 'FeatureCollection',
      features: trees
    };
  };

  const loadDummyTrees = async () => {
    try {
      console.log('Loading dummy trees...');
      
      // Generate dense tree grid (180 trees) - use this by default
      const embeddedGeoJSON = generateDenseTreeGrid();
      
      // Use embedded generated data (always has 180 trees)
      // Only try to fetch from file if we want to override (currently disabled)
      let geojson = embeddedGeoJSON;
      
      // File fetch disabled - using embedded generated data
      // Uncomment below if you want to load from file instead:
      /*
      try {
        const response = await fetch('/data/dummyTrees.geojson');
        if (response.ok) {
          const fetched = await response.json();
          if (fetched.features && fetched.features.length > 0) {
            geojson = fetched;
            console.log('Loaded dummy trees from file');
          }
        }
      } catch (fetchError) {
        console.log('Using embedded dummy tree data');
      }
      */
      
      console.log('Dummy trees loaded:', geojson.features?.length, 'trees');
      setDummyTreeCount(geojson.features?.length || 180);
      
      if (!geojson.features || geojson.features.length === 0) {
        throw new Error('No features found in GeoJSON');
      }
      
      if (!map.current) {
        console.error('Map not available');
        return;
      }

      // Wait for map to be ready
      const addDummyTreesLayer = () => {
        if (!map.current || !map.current.isStyleLoaded()) {
          setTimeout(addDummyTreesLayer, 100);
          return;
        }

        try {
          // Remove existing source and layer if they exist
          if (map.current.getLayer('dummy-trees-layer')) {
            map.current.removeLayer('dummy-trees-layer');
          }
          if (map.current.getSource('dummy-trees-source')) {
            map.current.removeSource('dummy-trees-source');
          }
          
          // Add dummy trees source
          map.current.addSource('dummy-trees-source', {
            type: 'geojson',
            data: geojson
          });

        // Add dummy trees layer - add before any existing layers
        try {
          map.current.addLayer({
            id: 'dummy-trees-layer',
            type: 'circle',
            source: 'dummy-trees-source',
            paint: {
              'circle-radius': [
                'interpolate',
                ['linear'],
                ['zoom'],
                10, 4,
                15, 7,
                20, 12
              ],
              'circle-color': [
                'interpolate',
                ['linear'],
                ['get', 'healthScore'],
                1, '#FF0000',
                2, '#FF8800',
                3, '#FFFF00',
                4, '#88FF00',
                5, '#00FF00'
              ],
              'circle-stroke-width': 2,
              'circle-stroke-color': '#ffffff',
              'circle-opacity': 0.9
            }
          });
          console.log('Dummy trees layer added successfully');
        } catch (layerError: any) {
          console.error('Error adding layer:', layerError);
          // Try adding without beforeId
          try {
            map.current.addLayer({
              id: 'dummy-trees-layer',
              type: 'circle',
              source: 'dummy-trees-source',
              paint: {
                'circle-radius': 6,
                'circle-color': [
                  'interpolate',
                  ['linear'],
                  ['get', 'healthScore'],
                  1, '#FF0000',
                  2, '#FF8800',
                  3, '#FFFF00',
                  4, '#88FF00',
                  5, '#00FF00'
                ],
                'circle-stroke-width': 2,
                'circle-stroke-color': '#ffffff',
                'circle-opacity': 0.9
              }
            });
            console.log('Dummy trees layer added (simplified)');
          } catch (err2) {
            console.error('Failed to add layer even with simplified config:', err2);
          }
        }

          // Show the layer by default
          map.current.setLayoutProperty('dummy-trees-layer', 'visibility', 'visible');
          console.log('Dummy trees layer added and visible');
          
          // Calculate bounds of dummy trees and fit map to them
          if (geojson.features && geojson.features.length > 0) {
            const bounds = new mapboxgl.LngLatBounds();
            geojson.features.forEach((feature: any) => {
              if (feature.geometry && feature.geometry.coordinates) {
                bounds.extend(feature.geometry.coordinates);
              }
            });
            
            // Fit bounds after a short delay to ensure layer is rendered
            setTimeout(() => {
              if (map.current) {
                map.current.fitBounds(bounds, {
                  padding: { top: 150, bottom: 150, left: 150, right: 150 },
                  maxZoom: 16,
                  duration: 1500
                });
                console.log('Map fitted to dummy trees bounds');
              }
            }, 500);
          }
        } catch (layerError) {
          console.error('Error adding dummy trees layer:', layerError);
        }
      };

      addDummyTreesLayer();
    } catch (err) {
      console.error('Error loading dummy trees:', err);
    }
  };

  const toggleDummyTrees = () => {
    if (map.current && map.current.getLayer('dummy-trees-layer')) {
      const visibility = showDummyTrees ? 'none' : 'visible';
      map.current.setLayoutProperty('dummy-trees-layer', 'visibility', visibility);
      setShowDummyTrees(!showDummyTrees);
    }
  };

  const calculateAreaSize = (feature: any) => {
    if (!feature || !feature.geometry || feature.geometry.type !== 'Polygon') {
      setDrawnAreaSize(null);
      return;
    }

    // Simple area calculation using shoelace formula (approximate for small areas)
    const coords = feature.geometry.coordinates[0];
    if (coords.length < 3) {
      setDrawnAreaSize(null);
      return;
    }

    let area = 0;
    for (let i = 0; i < coords.length - 1; i++) {
      area += coords[i][0] * coords[i + 1][1];
      area -= coords[i + 1][0] * coords[i][1];
    }
    area = Math.abs(area) / 2;

    // Convert to hectares (rough approximation)
    // 1 degree latitude ≈ 111 km, 1 degree longitude ≈ 111 km * cos(latitude)
    const lat = coords[0][1];
    const latKm = 111;
    const lonKm = 111 * Math.cos(lat * Math.PI / 180);
    const areaKm2 = area * latKm * lonKm;
    const areaHa = areaKm2 * 100; // Convert to hectares

    setDrawnAreaSize(areaHa);
  };

  const runBaselineAssessment = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get coordinates from drawn polygon - REQUIRED
      let coordinates = null;
      if (draw.current) {
        const features = draw.current.getAll();
        if (features.features.length > 0) {
          coordinates = features.features[0].geometry.coordinates[0];
        }
      }

      // Validate that a polygon has been drawn
      if (!coordinates || coordinates.length < 3) {
        setError('Please draw an area on the map first using the "Draw Area" button');
        setLoading(false);
        return;
      }

      // Check if area is too large (optional warning)
      const response = await fetch('http://localhost:3000/api/baseline-assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ coordinates })
      });

      if (!response.ok) throw new Error('Failed to run baseline assessment');

      const data = await response.json();
      console.log('Baseline assessment data received:', data);
      setBaselineData(data);

      // Add layers to map - ensure map is ready
      if (map.current) {
        // Wait for map to be fully loaded
        const addLayersWhenReady = () => {
          if (map.current && map.current.isStyleLoaded() && map.current.loaded()) {
            addLayersToMap(data);
          } else {
            // Wait a bit more
            setTimeout(addLayersWhenReady, 200);
          }
        };
        
        if (map.current.isStyleLoaded() && map.current.loaded()) {
          addLayersToMap(data);
        } else {
          map.current.once('load', () => {
            setTimeout(() => addLayersToMap(data), 300);
          });
        }
      }
      
      // Scroll to results panel
      setTimeout(() => {
        const resultsPanel = document.querySelector('.results-panel');
        if (resultsPanel) {
          resultsPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }, 100);
    } catch (err) {
      console.error('Assessment error:', err);
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const addLayersToMap = (data: BaselineData) => {
    if (!map.current) {
      console.error('Map not initialized');
      return;
    }

    console.log('Adding layers to map:', data);
    console.log('Map style loaded:', map.current.isStyleLoaded());
    console.log('Map loaded:', map.current.loaded());
    
    // Ensure map is ready before adding layers
    const addAllLayers = () => {
      if (!map.current) {
        console.error('Map is null');
        return;
      }
      
      if (!map.current.isStyleLoaded() || !map.current.loaded()) {
        console.warn('Map not ready, waiting...', {
          styleLoaded: map.current.isStyleLoaded(),
          loaded: map.current.loaded()
        });
        setTimeout(addAllLayers, 200);
        return;
      }
      
      console.log('Map is ready, adding layers now...');

      // Add NDVI layer
      if (data.baselineImagery?.ndviMapId) {
        try {
          // Remove existing layer if present
          if (map.current.getLayer('ndvi-layer')) {
            map.current.removeLayer('ndvi-layer');
          }
          if (map.current.getSource('ndvi-source')) {
            map.current.removeSource('ndvi-source');
          }

          // Use the urlFormat directly from backend
          let ndviUrl = data.baselineImagery.ndviUrlFormat;
          const mapId = data.baselineImagery.ndviMapId;
          const token = data.baselineImagery.ndviToken || mapId;
          
          if (!ndviUrl) {
            // Fallback: construct URL from mapId
            if (mapId.includes('/v1/projects/') || mapId.includes('earthengine-legacy')) {
              // v1 API - mapid contains the full path
              ndviUrl = `https://earthengine.googleapis.com/v1/${mapId}/tiles/{z}/{x}/{y}`;
            } else {
              // Legacy format
              ndviUrl = `https://earthengine.googleapis.com/map/${mapId}/{z}/{x}/{y}`;
            }
          }
          
          // For v1 API, use urlFormat as-is (it already has proper auth from getMapId)
          // Only modify legacy format URLs
          if (!ndviUrl.includes('/v1/projects/') && !ndviUrl.includes('earthengine-legacy')) {
            // Legacy format - ensure token is present
            if (!ndviUrl.includes('token=') && !ndviUrl.includes('access_token=')) {
              ndviUrl = `${ndviUrl}${ndviUrl.includes('?') ? '&' : '?'}token=${encodeURIComponent(token)}`;
            }
          }
          // For v1 API, don't modify the urlFormat - it's already correct from getMapId
          
          console.log('Adding NDVI layer with URL:', ndviUrl);
          console.log('NDVI Map ID:', mapId);
          console.log('NDVI Token:', token);
          
          try {
            // Remove existing source/layer first
            if (map.current.getSource('ndvi-source')) {
              try {
                if (map.current.getLayer('ndvi-layer')) {
                  map.current.removeLayer('ndvi-layer');
                }
                map.current.removeSource('ndvi-source');
              } catch (removeErr) {
                console.warn('Error removing existing NDVI layer:', removeErr);
              }
            }
            
            map.current.addSource('ndvi-source', {
              type: 'raster',
              tiles: [ndviUrl],
              tileSize: 256,
              // Add minzoom and maxzoom to ensure tiles load at all zoom levels
              minzoom: 0,
              maxzoom: 22
            });

            // Add layer without beforeId - just add it
            let layerAdded = false;
            try {
              map.current.addLayer({
                id: 'ndvi-layer',
                type: 'raster',
                source: 'ndvi-source',
                paint: { 
                  'raster-opacity': 0.7,
                  'raster-resampling': 'linear'
                },
                layout: { 'visibility': 'visible' },
                minzoom: 0,
                maxzoom: 22
              });
              layerAdded = true;
            } catch (addErr) {
              console.error('Error adding NDVI layer:', addErr);
            }
            
            if (layerAdded) {
              console.log('NDVI layer added successfully');
              // Verify immediately and check visibility
              setTimeout(() => {
                if (map.current) {
                  const layer = map.current.getLayer('ndvi-layer');
                  const source = map.current.getSource('ndvi-source');
                  const visibility = layer ? map.current.getLayoutProperty('ndvi-layer', 'visibility') : null;
                  console.log('NDVI layer verification:', {
                    layerExists: !!layer,
                    sourceExists: !!source,
                    visibility: visibility,
                    opacity: layer ? map.current.getPaintProperty('ndvi-layer', 'raster-opacity') : null
                  });
                  
                  // Ensure visibility is correct
                  if (layer && visibility !== 'visible') {
                    console.warn('NDVI layer not visible, fixing...');
                    map.current.setLayoutProperty('ndvi-layer', 'visibility', 'visible');
                  }
                }
              }, 500);
            }
          } catch (err) {
            console.error('Error adding NDVI layer:', err);
          }
          
          // Verify layer was added
          setTimeout(() => {
            if (map.current) {
              const layer = map.current.getLayer('ndvi-layer');
              const source = map.current.getSource('ndvi-source');
              console.log('NDVI layer verification:', {
                layerExists: !!layer,
                sourceExists: !!source,
                visibility: layer ? map.current.getLayoutProperty('ndvi-layer', 'visibility') : 'N/A',
                opacity: layer ? map.current.getPaintProperty('ndvi-layer', 'raster-opacity') : 'N/A'
              });
              
              // Test if tiles are loading
              if (source && 'tiles' in source) {
                console.log('NDVI source tiles:', source.tiles);
              }
            }
          }, 1000);
        } catch (err) {
          console.error('Error adding NDVI layer:', err);
        }
      }

      // Add EVI layer
      if (data.baselineImagery?.eviMapId) {
        try {
          if (map.current.getLayer('evi-layer')) {
            map.current.removeLayer('evi-layer');
          }
          if (map.current.getSource('evi-source')) {
            map.current.removeSource('evi-source');
          }

          const eviMapId = data.baselineImagery.eviMapId;
          let eviUrl = data.baselineImagery.eviUrlFormat;
          
          if (!eviUrl) {
            if (eviMapId.includes('/v1/projects/') || eviMapId.includes('earthengine-legacy')) {
              eviUrl = `https://earthengine.googleapis.com/v1/${eviMapId}/tiles/{z}/{x}/{y}`;
            } else {
              const eviToken = data.baselineImagery.eviToken || eviMapId;
              eviUrl = `https://earthengine.googleapis.com/map/${eviMapId}/{z}/{x}/{y}?token=${encodeURIComponent(eviToken)}`;
            }
          }
          
          // For v1 API, use urlFormat as-is (it already has proper auth from getMapId)
          // Only modify legacy format URLs
          if (!eviUrl.includes('/v1/projects/') && !eviUrl.includes('earthengine-legacy')) {
            const eviToken = data.baselineImagery.eviToken || eviMapId;
            if (!eviUrl.includes('token=') && !eviUrl.includes('access_token=')) {
              eviUrl = `${eviUrl}${eviUrl.includes('?') ? '&' : '?'}token=${encodeURIComponent(eviToken)}`;
            }
          }
          // For v1 API, don't modify the urlFormat - it's already correct from getMapId
          
          console.log('Adding EVI layer with URL:', eviUrl);
          
          map.current.addSource('evi-source', {
            type: 'raster',
            tiles: [eviUrl],
            tileSize: 256,
            minzoom: 0,
            maxzoom: 22
          });

          let layerAdded = false;
          try {
            // Add layer without beforeId
            map.current.addLayer({
              id: 'evi-layer',
              type: 'raster',
              source: 'evi-source',
              paint: { 
                'raster-opacity': 0.7,
                'raster-resampling': 'linear'
              },
              layout: { 'visibility': 'none' },
              minzoom: 0,
              maxzoom: 22
            });
            layerAdded = true;
          } catch (addErr) {
            console.error('Error adding EVI layer:', addErr);
          }
          
          if (layerAdded) {
            console.log('EVI layer added successfully');
            // Verify
            setTimeout(() => {
              if (map.current) {
                const layer = map.current.getLayer('evi-layer');
                console.log('EVI layer exists:', !!layer);
              }
            }, 500);
          }
        } catch (err) {
          console.error('Error adding EVI layer:', err);
        }
      }

      // Add Canopy Cover layer
      if (data.existingVegetation?.canopyMapId) {
        try {
          if (map.current.getLayer('canopy-layer')) {
            map.current.removeLayer('canopy-layer');
          }
          if (map.current.getSource('canopy-source')) {
            map.current.removeSource('canopy-source');
          }

          const canopyMapId = data.existingVegetation.canopyMapId;
          let canopyUrl = data.existingVegetation.canopyUrlFormat;
          
          if (!canopyUrl) {
            // Fallback: construct URL from mapId
            const canopyToken = data.existingVegetation.canopyToken || canopyMapId;
            if (canopyMapId.includes('/v1/projects/') || canopyMapId.includes('earthengine-legacy')) {
              canopyUrl = `https://earthengine.googleapis.com/v1/${canopyMapId}/tiles/{z}/{x}/{y}`;
            } else {
              canopyUrl = `https://earthengine.googleapis.com/map/${canopyMapId}/{z}/{x}/{y}?token=${encodeURIComponent(canopyToken)}`;
            }
          }
          
          // For v1 API, use urlFormat as-is (it already has proper auth)
          // Only modify legacy format URLs
          if (!canopyUrl.includes('/v1/projects/') && !canopyUrl.includes('earthengine-legacy')) {
            const canopyToken = data.existingVegetation.canopyToken || canopyMapId;
            if (!canopyUrl.includes('token=') && !canopyUrl.includes('access_token=')) {
              canopyUrl = `${canopyUrl}${canopyUrl.includes('?') ? '&' : '?'}token=${encodeURIComponent(canopyToken)}`;
            }
          }
          // For v1 API, don't modify the urlFormat - it's already correct
          
          console.log('Adding Canopy layer with URL:', canopyUrl);
          console.log('Canopy Token:', data.existingVegetation.canopyToken || canopyMapId);
          
          try {
            if (map.current.getSource('canopy-source')) {
              try {
                if (map.current.getLayer('canopy-layer')) {
                  map.current.removeLayer('canopy-layer');
                }
                map.current.removeSource('canopy-source');
              } catch (removeErr) {
                console.warn('Error removing existing Canopy layer:', removeErr);
              }
            }
            
            map.current.addSource('canopy-source', {
              type: 'raster',
              tiles: [canopyUrl],
              tileSize: 256,
              minzoom: 0,
              maxzoom: 22
            });

            let layerAdded = false;
            try {
              // Add layer without beforeId
              map.current.addLayer({
                id: 'canopy-layer',
                type: 'raster',
                source: 'canopy-source',
                paint: { 
                  'raster-opacity': 0.5,
                  'raster-resampling': 'linear'
                },
                layout: { 'visibility': 'none' },
                minzoom: 0,
                maxzoom: 22
              });
              layerAdded = true;
            } catch (addErr) {
              console.error('Error adding Canopy layer:', addErr);
            }
            
            if (layerAdded) {
              console.log('Canopy layer added successfully');
            }
          } catch (err) {
            console.error('Error adding Canopy layer:', err);
          }
        } catch (err) {
          console.error('Error adding Canopy layer:', err);
        }
      }

      // Add tree points
      if (data.existingVegetation?.trees && data.existingVegetation.trees.length > 0) {
        console.log(`Adding ${data.existingVegetation.trees.length} tree points to map`);
        
        const treeFeatures = data.existingVegetation.trees
          .filter((tree: any) => {
            if (!tree || !tree.coordinates || !Array.isArray(tree.coordinates)) {
              return false;
            }
            const coords = tree.coordinates;
            if (coords.length !== 2) return false;
            if (!isFinite(coords[0]) || !isFinite(coords[1])) return false;
            // Validate coordinate ranges (rough sanity check for Saudi Arabia region)
            // Longitude: 34-55, Latitude: 16-33
            if (coords[0] < 34 || coords[0] > 55 || coords[1] < 16 || coords[1] > 33) {
              console.warn('Tree coordinates out of expected range:', coords);
              return false;
            }
            return true;
          })
          .map((tree: any) => ({
            type: 'Feature',
            geometry: {
              type: 'Point',
              coordinates: tree.coordinates // Should be [lng, lat]
            },
            properties: {
              id: tree.id || 0,
              healthScore: tree.healthScore || 1,
              ndvi: tree.ndvi || 0
            }
          }));

        console.log(`Filtered to ${treeFeatures.length} valid tree features from ${data.existingVegetation.trees.length} total`);

        if (treeFeatures.length > 0) {
          try {
            if (map.current.getLayer('trees-layer')) {
              map.current.removeLayer('trees-layer');
            }
            if (map.current.getSource('trees-source')) {
              map.current.removeSource('trees-source');
            }

            map.current.addSource('trees-source', {
              type: 'geojson',
              data: {
                type: 'FeatureCollection',
                features: treeFeatures
              }
            });

            let treeLayerAdded = false;
            try {
              // Add layer without beforeId
              map.current.addLayer({
                id: 'trees-layer',
                type: 'circle',
                source: 'trees-source',
                paint: {
                  'circle-radius': [
                    'interpolate',
                    ['linear'],
                    ['zoom'],
                    10, 4,
                    15, 7,
                    20, 12
                  ],
                  'circle-color': [
                    'interpolate',
                    ['linear'],
                    ['get', 'healthScore'],
                    1, '#FF0000',
                    2, '#FF8800',
                    3, '#FFFF00',
                    4, '#88FF00',
                    5, '#00FF00'
                  ],
                  'circle-stroke-width': 2,
                  'circle-stroke-color': '#ffffff',
                  'circle-opacity': 0.9
                },
                layout: { 'visibility': 'visible' }
              });
              treeLayerAdded = true;
            } catch (layerErr) {
              console.error('Error adding tree layer:', layerErr);
              // Try one more time with simpler config
              try {
                map.current.addLayer({
                  id: 'trees-layer',
                  type: 'circle',
                  source: 'trees-source',
                  paint: {
                    'circle-radius': 8,
                    'circle-color': '#00FF00',
                    'circle-stroke-width': 2,
                    'circle-stroke-color': '#ffffff',
                    'circle-opacity': 0.9
                  },
                  layout: { 'visibility': 'visible' }
                });
                treeLayerAdded = true;
              } catch (finalErr) {
                console.error('Final error adding tree layer:', finalErr);
              }
            }
            
            if (treeLayerAdded) {
              console.log('Tree points layer added successfully');
              // Verify immediately
              const layer = map.current.getLayer('trees-layer');
              console.log('Tree layer exists after add:', !!layer);
              if (layer) {
                console.log('Tree layer visibility:', map.current.getLayoutProperty('trees-layer', 'visibility'));
              }
            } else {
              console.error('Failed to add tree layer');
            }
            console.log('Tree layer exists:', map.current.getLayer('trees-layer') !== undefined);
            console.log('Tree layer visibility:', map.current.getLayoutProperty('trees-layer', 'visibility'));
          } catch (err) {
            console.error('Error adding tree points layer:', err);
          }
        } else {
          console.warn('No valid tree features to add to map after filtering');
        }
      } else {
        console.warn('No trees found in vegetation data:', data.existingVegetation);
      }
    };
    
    // Call addAllLayers when map is ready
    if (map.current.isStyleLoaded()) {
      addAllLayers();
    } else {
      map.current.once('style.load', addAllLayers);
    }
  };

  const prepareChartData = () => {
    if (!baselineData) return null;

    const siteDef = baselineData.siteDefinition || {};
    const veg = baselineData.existingVegetation || {};
    const agb = baselineData.agbEstimation || {};
    const imagery = baselineData.baselineImagery || {};

    // Create NDVI distribution histogram data based on actual stats
    const ndviStats = imagery.ndviStats || {};
    const ndviMean = ndviStats.mean || 0;
    const ndviMin = ndviStats.min || -1;
    const ndviMax = ndviStats.max || 1;
    
    // Calculate distribution based on mean and range
    const ndviRange = ndviMax - ndviMin;
    const ndviDistribution = [
      { range: 'Very Low\n(-1.0 to 0.0)', value: ndviMean < 0 ? Math.max(0, (0 - ndviMin) / ndviRange * 100) : 5, color: '#8B0000' },
      { range: 'Low\n(0.0 to 0.2)', value: ndviMean >= 0 && ndviMean < 0.2 ? Math.max(0, (0.2 - Math.max(0, ndviMin)) / ndviRange * 100) : 10, color: '#FF0000' },
      { range: 'Moderate\n(0.2 to 0.4)', value: ndviMean >= 0.2 && ndviMean < 0.4 ? Math.max(0, (0.4 - 0.2) / ndviRange * 100) : 20, color: '#FFFF00' },
      { range: 'Good\n(0.4 to 0.6)', value: ndviMean >= 0.4 && ndviMean < 0.6 ? Math.max(0, (0.6 - 0.4) / ndviRange * 100) : 30, color: '#90EE90' },
      { range: 'High\n(0.6 to 0.8)', value: ndviMean >= 0.6 && ndviMean < 0.8 ? Math.max(0, (0.8 - 0.6) / ndviRange * 100) : 25, color: '#228B22' },
      { range: 'Very High\n(0.8 to 1.0)', value: ndviMean >= 0.8 ? Math.max(0, (ndviMax - 0.8) / ndviRange * 100) : 10, color: '#006400' }
    ];

    // Create EVI distribution histogram data
    const eviStats = imagery.eviStats || {};
    const eviMean = eviStats.mean || 0;
    const eviMin = eviStats.min || -1;
    const eviMax = eviStats.max || 1;
    const eviRange = eviMax - eviMin;
    
    const eviDistribution = [
      { range: 'Very Low\n(-1.0 to 0.0)', value: eviMean < 0 ? Math.max(0, (0 - eviMin) / eviRange * 100) : 5, color: '#8B0000' },
      { range: 'Low\n(0.0 to 0.2)', value: eviMean >= 0 && eviMean < 0.2 ? Math.max(0, (0.2 - Math.max(0, eviMin)) / eviRange * 100) : 8, color: '#FF0000' },
      { range: 'Moderate\n(0.2 to 0.4)', value: eviMean >= 0.2 && eviMean < 0.4 ? Math.max(0, (0.4 - 0.2) / eviRange * 100) : 15, color: '#FFFF00' },
      { range: 'Good\n(0.4 to 0.6)', value: eviMean >= 0.4 && eviMean < 0.6 ? Math.max(0, (0.6 - 0.4) / eviRange * 100) : 35, color: '#90EE90' },
      { range: 'High\n(0.6 to 0.8)', value: eviMean >= 0.6 && eviMean < 0.8 ? Math.max(0, (0.8 - 0.6) / eviRange * 100) : 30, color: '#228B22' },
      { range: 'Very High\n(0.8 to 1.0)', value: eviMean >= 0.8 ? Math.max(0, (eviMax - 0.8) / eviRange * 100) : 7, color: '#006400' }
    ];

    // Vegetation health distribution based on canopy cover
    // Try both property names (backend has typo 'canonopyCoverPercent')
    const canopyCover = veg.canonopyCoverPercent || veg.canonopyCoverPercent || baselineData.existingVegetation?.canopyCoverPercent || 0;
    
    console.log('Canopy cover value:', canopyCover, 'veg object:', veg);
    
    // Create a realistic distribution that always shows meaningful data
    // Use canopy cover as a base, but ensure minimum visibility
    let excellent = 0, good = 0, moderate = 0, fair = 0, poor = 0;
    
    // If canopy cover is very low or zero, create a default distribution
    if (canopyCover <= 0 || !canopyCover) {
      // Default distribution for areas with no/low vegetation
      excellent = 0;
      good = 0;
      moderate = 5; // Show some moderate
      fair = 10; // Show some fair
      poor = 15; // Most is poor
    } else if (canopyCover > 70) {
      excellent = Math.max(35, canopyCover * 0.5); // 50% of high cover is excellent
      good = Math.max(20, canopyCover * 0.3); // 30% is good
      moderate = Math.max(10, canopyCover * 0.15); // 15% is moderate
      fair = Math.max(5, canopyCover * 0.05); // 5% is fair
      poor = 0;
    } else if (canopyCover > 50) {
      excellent = Math.max(10, canopyCover * 0.2);
      good = Math.max(25, canopyCover * 0.5);
      moderate = Math.max(15, canopyCover * 0.25);
      fair = Math.max(5, canopyCover * 0.05);
      poor = 0;
    } else if (canopyCover > 30) {
      excellent = 0;
      good = Math.max(10, canopyCover * 0.3);
      moderate = Math.max(15, canopyCover * 0.5);
      fair = Math.max(5, canopyCover * 0.15);
      poor = Math.max(2, canopyCover * 0.05);
    } else if (canopyCover > 10) {
      excellent = 0;
      good = Math.max(3, canopyCover * 0.2);
      moderate = Math.max(8, canopyCover * 0.4);
      fair = Math.max(8, canopyCover * 0.3);
      poor = Math.max(5, canopyCover * 0.1);
    } else {
      // Low canopy cover
      excellent = 0;
      good = 0;
      moderate = Math.max(3, canopyCover * 0.3);
      fair = Math.max(5, canopyCover * 0.4);
      poor = Math.max(10, canopyCover * 0.3);
    }
    
    const healthDistribution = [
      { category: 'Excellent\n(>70% cover)', value: Math.max(0, Math.round(excellent)), color: '#006400' },
      { category: 'Good\n(50-70%)', value: Math.max(0, Math.round(good)), color: '#228B22' },
      { category: 'Moderate\n(30-50%)', value: Math.max(0, Math.round(moderate)), color: '#90EE90' },
      { category: 'Fair\n(10-30%)', value: Math.max(0, Math.round(fair)), color: '#FFFF00' },
      { category: 'Poor\n(<10%)', value: Math.max(0, Math.round(poor)), color: '#FF0000' }
    ];
    
    console.log('Health distribution:', healthDistribution);

    const chartData = {
      siteDefinition: [
        { name: 'Candidate Sites', value: siteDef.candidateAreaPercent || 0 },
        { name: 'Constraints', value: siteDef.constraintAreaPercent || 0 },
        { name: 'Other', value: Math.max(0, 100 - (siteDef.candidateAreaPercent || 0) - (siteDef.constraintAreaPercent || 0)) }
      ],
      ndviDistribution: ndviDistribution,
      eviDistribution: eviDistribution,
      healthDistribution: healthDistribution,
      agbDistribution: (agb.treesWithAGB || []).map((tree: any, idx: number) => ({
        name: `Sample ${idx + 1}`,
        agb: tree.agb || 0
      })).slice(0, 30) || []
    };

    console.log('Chart data prepared:', chartData);
    return chartData;
  };

  const chartData = prepareChartData();

  return (
    <div className="baseline-container">
      <nav className="top-nav">
        <div className="nav-left">
          <MapIcon className="nav-icon" />
          <h1>URIMPACT Baseline Assessment - Wadi Al Batha</h1>
        </div>
        <div className="nav-right">
          <button 
            className="help-button"
            onClick={() => setActiveTab('overview')}
          >
            <HelpCircle size={20} />
            Help
          </button>
        </div>
      </nav>

      <div className="main-content">
        <div className="tools-panel">
          <div className="tools-section">
            <h3>Assessment Tools</h3>
            <div className="instructions-box">
              <p><strong>Step 1:</strong> Click "Draw Area" button</p>
              <p><strong>Step 2:</strong> Click on map to create polygon points</p>
              <p><strong>Step 3:</strong> Double-click to complete the area</p>
              <p><strong>Step 4:</strong> Click "Run Assessment"</p>
              {drawnAreaSize !== null && (
                <p style={{ marginTop: '0.75rem', paddingTop: '0.75rem', borderTop: '1px solid #ddd', fontWeight: '600', color: '#667eea' }}>
                  Selected Area: {drawnAreaSize.toFixed(2)} hectares
                </p>
              )}
            </div>
            <div className="tools-buttons">
              <button 
                className="tool-button draw-button"
                onClick={() => {
                  if (draw.current) {
                    draw.current.changeMode('draw_polygon');
                    setError(null);
                  }
                }}
              >
                <Layers size={18} />
                Draw Area
              </button>
              <button 
                className="tool-button primary"
                onClick={runBaselineAssessment}
                disabled={loading}
              >
                <Activity size={18} />
                {loading ? 'Running Assessment...' : 'Run Baseline Assessment'}
              </button>
              <button 
                className="tool-button"
                onClick={() => {
                  if (draw.current) draw.current.deleteAll();
                  if (map.current) {
                    if (map.current.getLayer('ndvi-layer')) map.current.removeLayer('ndvi-layer');
                    if (map.current.getSource('ndvi-source')) map.current.removeSource('ndvi-source');
                    if (map.current.getLayer('trees-layer')) map.current.removeLayer('trees-layer');
                    if (map.current.getSource('trees-source')) map.current.removeSource('trees-source');
                  }
                  setBaselineData(null);
                  setError(null);
                }}
              >
                <Trash2 size={18} />
                Clear
              </button>
            </div>
          </div>

          <div className="tabs">
            <button 
              className={activeTab === 'overview' ? 'tab active' : 'tab'}
              onClick={() => setActiveTab('overview')}
            >
              <BarChart3 size={16} />
              Overview
            </button>
            <button 
              className={activeTab === 'site' ? 'tab active' : 'tab'}
              onClick={() => setActiveTab('site')}
            >
              <MapIcon size={16} />
              Site Definition
            </button>
            <button 
              className={activeTab === 'vegetation' ? 'tab active' : 'tab'}
              onClick={() => setActiveTab('vegetation')}
            >
              <TreePine size={16} />
              Vegetation
            </button>
            <button 
              className={activeTab === 'agb' ? 'tab active' : 'tab'}
              onClick={() => setActiveTab('agb')}
            >
              <Leaf size={16} />
              AGB Estimation
            </button>
            <button 
              className={activeTab === 'imagery' ? 'tab active' : 'tab'}
              onClick={() => setActiveTab('imagery')}
            >
              <Layers size={16} />
              Imagery & Indices
            </button>
          </div>
        </div>

        <div className="content-area">
          <div className="map-wrapper">
            <div ref={mapContainer} className="map" />
            
            <LayerControls
              map={map.current}
              hasNDVI={!!baselineData?.baselineImagery?.ndviMapId}
              hasEVI={!!baselineData?.baselineImagery?.eviMapId}
              hasCanopy={!!baselineData?.existingVegetation?.canopyMapId}
              hasTrees={!!(baselineData?.existingVegetation?.trees && baselineData.existingVegetation.trees.length > 0)}
              showDummyTrees={showDummyTrees}
              onToggleDummyTrees={toggleDummyTrees}
              dummyTreeCount={dummyTreeCount}
            />
            
            {loading && (
              <div className="loading-overlay">
                <div className="loading-content">
                  <Circle className="loading-icon" />
                  <span>Running Baseline Assessment...</span>
                </div>
              </div>
            )}

            {error && (
              <div className="error-message">{error}</div>
            )}
          </div>

          {baselineData && (
            <div className="results-panel">
              <div style={{ 
                marginBottom: '1.5rem', 
                padding: '1rem 1.25rem', 
                background: 'linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)', 
                borderRadius: '12px', 
                border: '1px solid #10b981',
                color: '#065f46',
                fontWeight: '500',
                boxShadow: '0 2px 8px rgba(16, 185, 129, 0.15)'
              }}>
                <strong>✓ Assessment Complete!</strong> View results below or use tabs to explore different metrics.
              </div>
              {activeTab === 'overview' && (
                <div className="results-content">
                  <h2>Baseline Assessment Overview</h2>
                  
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <h3>Total Area</h3>
                      <p className="metric-value">{baselineData.siteDefinition?.totalArea?.toFixed(2)} ha</p>
                    </div>
                    <div className="metric-card">
                      <h3>Canopy Cover</h3>
                      <p className="metric-value">{baselineData.existingVegetation?.canopyCoverPercent?.toFixed(2)}%</p>
                    </div>
                    <div className="metric-card">
                      <h3>Total AGB</h3>
                      <p className="metric-value">{baselineData.agbEstimation?.totalAGBTonnes?.toFixed(2)} tonnes</p>
                    </div>
                    <div className="metric-card">
                      <h3>Average NDVI</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.ndviStats?.mean?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>Average EVI</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.eviStats?.mean?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>Candidate Sites</h3>
                      <p className="metric-value">{baselineData.siteDefinition?.candidateAreaPercent?.toFixed(1)}%</p>
                    </div>
                  </div>

                  {chartData && (
                    <div className="charts-grid">
                      <div className="chart-card">
                        <h3>Site Definition</h3>
                        {chartData.siteDefinition.some((d: any) => d.value > 0) ? (
                          <ResponsiveContainer width="100%" height={320}>
                            <PieChart>
                              <Pie
                                data={chartData.siteDefinition}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                outerRadius={90}
                                fill="#8884d8"
                                dataKey="value"
                                stroke="#fff"
                                strokeWidth={2}
                              >
                                {chartData.siteDefinition.map((entry: any, index: number) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: 'white', 
                                  border: '1px solid #e2e8f0',
                                  borderRadius: '8px',
                                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                }} 
                              />
                              <Legend 
                                wrapperStyle={{ paddingTop: '1rem' }}
                                iconType="circle"
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        ) : (
                          <div style={{ textAlign: 'center', color: '#94a3b8', padding: '3rem 2rem' }}>
                            <p style={{ margin: 0, fontSize: '0.95rem' }}>No site definition data available</p>
                          </div>
                        )}
                      </div>

                      <div className="chart-card">
                        <h3>NDVI Distribution</h3>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart data={chartData.ndviDistribution}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="range" stroke="#64748b" angle={-45} textAnchor="end" height={100} />
                            <YAxis stroke="#64748b" />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: 'white', 
                                border: '1px solid #e2e8f0',
                                borderRadius: '8px',
                                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                              }} 
                            />
                            <Legend />
                            <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                              {chartData.ndviDistribution.map((entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="chart-card">
                        <h3>EVI Distribution</h3>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart data={chartData.eviDistribution}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="range" stroke="#64748b" angle={-45} textAnchor="end" height={100} />
                            <YAxis stroke="#64748b" />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: 'white', 
                                border: '1px solid #e2e8f0',
                                borderRadius: '8px',
                                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                              }} 
                            />
                            <Legend />
                            <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                              {chartData.eviDistribution.map((entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="chart-card">
                        <h3>Vegetation Health</h3>
                        {chartData.healthDistribution && chartData.healthDistribution.some((d: any) => d.value > 0) ? (
                          <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={chartData.healthDistribution} margin={{ top: 20, right: 30, left: 20, bottom: 100 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                              <XAxis 
                                dataKey="category" 
                                stroke="#64748b" 
                                angle={-45} 
                                textAnchor="end" 
                                height={100}
                                tick={{ fontSize: 11 }}
                              />
                              <YAxis 
                                stroke="#64748b"
                                label={{ value: 'Cover %', angle: -90, position: 'insideLeft' }}
                              />
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: 'white', 
                                  border: '1px solid #e2e8f0',
                                  borderRadius: '8px',
                                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                }}
                                formatter={(value: any) => [`${value}%`, 'Cover']}
                              />
                              <Legend />
                              <Bar dataKey="value" radius={[8, 8, 0, 0]} name="Vegetation Cover">
                                {chartData.healthDistribution.map((entry: any, index: number) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        ) : (
                          <div style={{ textAlign: 'center', color: '#94a3b8', padding: '2rem' }}>
                            <p style={{ margin: 0, fontSize: '0.95rem' }}>No vegetation health data available</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  {!chartData && (
                    <div style={{ textAlign: 'center', color: '#94a3b8', padding: '3rem 2rem' }}>
                      <p style={{ margin: 0, fontSize: '0.95rem' }}>Loading chart data...</p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'site' && (
                <div className="results-content">
                  <h2>Site Definition</h2>
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <h3>Total Area</h3>
                      <p className="metric-value">{baselineData.siteDefinition?.totalArea?.toFixed(2)} ha</p>
                    </div>
                    <div className="metric-card">
                      <h3>Candidate Planting Area</h3>
                      <p className="metric-value">{baselineData.siteDefinition?.candidatePlantingArea?.toFixed(2)} ha</p>
                      <p className="metric-sub">{baselineData.siteDefinition?.candidateAreaPercent?.toFixed(2)}%</p>
                    </div>
                    <div className="metric-card">
                      <h3>Constraint Area</h3>
                      <p className="metric-value">{baselineData.siteDefinition?.constraintArea?.toFixed(2)} ha</p>
                      <p className="metric-sub">{baselineData.siteDefinition?.constraintAreaPercent?.toFixed(2)}%</p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'vegetation' && (
                <div className="results-content">
                  <h2>Existing Vegetation</h2>
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <h3>Canopy Cover</h3>
                      <p className="metric-value">{baselineData.existingVegetation?.canopyCoverPercent?.toFixed(2)}%</p>
                    </div>
                    <div className="metric-card">
                      <h3>Average NDVI</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.ndviStats?.mean?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>Average EVI</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.eviStats?.mean?.toFixed(3)}</p>
                    </div>
                  </div>
                  
                  {chartData && (
                    <div className="charts-grid">
                      <div className="chart-card">
                        <h3>NDVI Distribution</h3>
                        <ResponsiveContainer width="100%" height={350}>
                          <BarChart data={chartData.ndviDistribution}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="range" stroke="#64748b" angle={-45} textAnchor="end" height={100} />
                            <YAxis stroke="#64748b" label={{ value: 'Percentage', angle: -90, position: 'insideLeft' }} />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: 'white', 
                                border: '1px solid #e2e8f0',
                                borderRadius: '8px',
                                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                              }} 
                            />
                            <Legend />
                            <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                              {chartData.ndviDistribution.map((entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="chart-card">
                        <h3>EVI Distribution</h3>
                        <ResponsiveContainer width="100%" height={350}>
                          <BarChart data={chartData.eviDistribution}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="range" stroke="#64748b" angle={-45} textAnchor="end" height={100} />
                            <YAxis stroke="#64748b" label={{ value: 'Percentage', angle: -90, position: 'insideLeft' }} />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: 'white', 
                                border: '1px solid #e2e8f0',
                                borderRadius: '8px',
                                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                              }} 
                            />
                            <Legend />
                            <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                              {chartData.eviDistribution.map((entry: any, index: number) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="chart-card">
                        <h3>Vegetation Health Distribution</h3>
                        {chartData.healthDistribution && chartData.healthDistribution.some((d: any) => d.value > 0) ? (
                          <ResponsiveContainer width="100%" height={350}>
                            <BarChart data={chartData.healthDistribution} margin={{ top: 20, right: 30, left: 20, bottom: 100 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                              <XAxis 
                                dataKey="category" 
                                stroke="#64748b" 
                                angle={-45} 
                                textAnchor="end" 
                                height={100}
                                tick={{ fontSize: 11 }}
                              />
                              <YAxis 
                                stroke="#64748b"
                                label={{ value: 'Cover %', angle: -90, position: 'insideLeft' }}
                              />
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: 'white', 
                                  border: '1px solid #e2e8f0',
                                  borderRadius: '8px',
                                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                }}
                                formatter={(value: any) => [`${value}%`, 'Cover']}
                              />
                              <Legend />
                              <Bar dataKey="value" radius={[8, 8, 0, 0]} name="Vegetation Cover">
                                {chartData.healthDistribution.map((entry: any, index: number) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        ) : (
                          <div style={{ textAlign: 'center', color: '#94a3b8', padding: '3rem 2rem' }}>
                            <p style={{ margin: 0, fontSize: '0.95rem' }}>No vegetation health data available</p>
                            <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.85rem', color: '#cbd5e1' }}>
                              Canopy cover: {baselineData?.existingVegetation?.canopyCoverPercent?.toFixed(2) || 'N/A'}%
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'agb' && (
                <div className="results-content">
                  <h2>Above-Ground Biomass (AGB) Estimation</h2>
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <h3>Total AGB</h3>
                      <p className="metric-value">{baselineData.agbEstimation?.totalAGBTonnes?.toFixed(2)} tonnes</p>
                      <p className="metric-sub">{baselineData.agbEstimation?.totalAGB?.toFixed(2)} kg</p>
                    </div>
                    <div className="metric-card">
                      <h3>Average AGB</h3>
                      <p className="metric-value">{baselineData.agbEstimation?.averageAGB?.toFixed(2)} kg</p>
                    </div>
                    <div className="metric-card">
                      <h3>Trees Analyzed</h3>
                      <p className="metric-value">{baselineData.agbEstimation?.treesWithAGB?.length || 0}</p>
                    </div>
                  </div>

                  {chartData && chartData.agbDistribution.length > 0 ? (
                    <div className="chart-card">
                      <h3>AGB Distribution (Top 20 Trees)</h3>
                          <ResponsiveContainer width="100%" height={400}>
                        <BarChart data={chartData.agbDistribution} margin={{ top: 20, right: 30, left: 20, bottom: 80 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis 
                            dataKey="name" 
                            angle={-45} 
                            textAnchor="end" 
                            height={100}
                            stroke="#64748b"
                            fontSize={12}
                          />
                          <YAxis 
                            stroke="#64748b"
                            label={{ value: 'AGB (kg)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#64748b' } }}
                          />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'white', 
                              border: '1px solid #e2e8f0',
                              borderRadius: '8px',
                              boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                            }} 
                          />
                          <Legend />
                          <Bar 
                            dataKey="agb" 
                            fill="#f59e0b" 
                            radius={[8, 8, 0, 0]}
                            name="Above-Ground Biomass"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="chart-card">
                      <h3>AGB Distribution</h3>
                      <div style={{ textAlign: 'center', color: '#94a3b8', padding: '3rem 2rem' }}>
                        <p style={{ margin: 0, fontSize: '0.95rem' }}>
                          {baselineData.agbEstimation?.treesWithAGB?.length === 0 
                            ? 'No AGB data available for individual trees' 
                            : 'Loading AGB distribution data...'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'imagery' && (
                <div className="results-content">
                  <h2>Baseline Imagery & Vegetation Indices</h2>
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <h3>NDVI Mean</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.ndviStats?.mean?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>NDVI Range</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.ndviStats?.min?.toFixed(3)} - {baselineData.baselineImagery?.ndviStats?.max?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>EVI Mean</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.eviStats?.mean?.toFixed(3)}</p>
                    </div>
                    <div className="metric-card">
                      <h3>EVI Range</h3>
                      <p className="metric-value">{baselineData.baselineImagery?.eviStats?.min?.toFixed(3)} - {baselineData.baselineImagery?.eviStats?.max?.toFixed(3)}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BaselineAssessment;

