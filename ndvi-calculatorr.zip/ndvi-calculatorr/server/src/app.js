// src/app.js
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import ndviRoutes from './routes/ndviRoutes.js';
import mhiRoutes from './routes/mhiRoutes.js';
import agcRoutes from './routes/agcRoutes.js';
import socRoutes from './routes/socRoutes.js';
import baselineRoutes from './routes/baselineRoutes.js';
import { initEarthEngine } from './services/earthEngineService.js';
import dotenv from 'dotenv';

dotenv.config();
const app = express();

app.use(morgan('dev'));
app.use(cors({
  origin: 'http://localhost:5173',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type']
}));
app.use(express.json());

// Routes
app.use('/api', ndviRoutes);
app.use('/api', mhiRoutes);
app.use('/api', agcRoutes);
app.use('/api', socRoutes);
app.use('/api', baselineRoutes);

const PORT = process.env.PORT || 3000;

await initEarthEngine();
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));