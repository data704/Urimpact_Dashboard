// Baseline Assessment Controller
import { 
  performBaselineAssessment,
  analyzeSiteDefinition,
  analyzeExistingVegetation,
  estimateAGB,
  generateBaselineImagery,
  getWadiAlBathaAOI
} from '../services/baselineAssessmentService.js';

export const getBaselineAssessment = async (req, res) => {
  try {
    const { coordinates } = req.body;
    const results = await performBaselineAssessment(coordinates);
    res.json(results);
  } catch (error) {
    console.error('Baseline assessment error:', error);
    res.status(500).json({ error: error.message });
  }
};

export const getSiteDefinition = async (req, res) => {
  try {
    const { coordinates } = req.body;
    const results = await analyzeSiteDefinition(coordinates);
    res.json(results);
  } catch (error) {
    console.error('Site definition error:', error);
    res.status(500).json({ error: error.message });
  }
};

export const getExistingVegetation = async (req, res) => {
  try {
    const { coordinates } = req.body;
    const results = await analyzeExistingVegetation(coordinates);
    res.json(results);
  } catch (error) {
    console.error('Vegetation analysis error:', error);
    res.status(500).json({ error: error.message });
  }
};

export const getAGBEstimation = async (req, res) => {
  try {
    const { coordinates } = req.body;
    const results = await estimateAGB(coordinates);
    res.json(results);
  } catch (error) {
    console.error('AGB estimation error:', error);
    res.status(500).json({ error: error.message });
  }
};

export const getBaselineImagery = async (req, res) => {
  try {
    const { coordinates } = req.body;
    const results = await generateBaselineImagery(coordinates);
    res.json(results);
  } catch (error) {
    console.error('Baseline imagery error:', error);
    res.status(500).json({ error: error.message });
  }
};

export const getDefaultAOI = async (req, res) => {
  try {
    const { getWadiAlBathaAOI } = await import('../services/baselineAssessmentService.js');
    const aoi = getWadiAlBathaAOI();
    res.json({ aoi });
  } catch (error) {
    console.error('Get AOI error:', error);
    res.status(500).json({ error: error.message });
  }
};

